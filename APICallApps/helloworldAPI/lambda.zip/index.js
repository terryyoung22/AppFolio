exports.handler = async (event) => {
    const html = `
    <html>
    <head><title>Static Site</title></head>
    <body><h1>Welcome to My Static App!</h1></body>
    </html>`;
        
    return {
        statusCode: 200,
        headers: { "Content-Type": "text/html" },
        body: html,
    };
};
